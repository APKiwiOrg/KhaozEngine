import re, subprocess
runs = {
 'split, 16-bit targets (committed)': ['orig-r2', 'orig-r3'],
 'split, 32-bit targets (exact)': ['exact-r1', 'exact-r2'],
 'split + sin-free Lanczos': ['poly-r1', 'poly-r2'],
 'split + five-tap history clamp': ['tap5-r2', 'tap5-r3'],
 'split + half 3x3 (Metal)': ['half2-r1', 'half2-r2'],
 'split + half 3x3 + sin-free Lanczos': ['half2-poly-r1', 'half2-poly-r2'],
 'split + half 3x3 + Lanczos + five-tap': ['half2-poly-tap5-r1', 'half2-poly-tap5-r2'],
 'split + still layer (#1191 cost shape)': ['still-r1', 'still-r3'],
}
def parse(tag):
    rows = {}; cur = None; load = ''
    for l in open(f'/tmp/taa-split/cost-{tag}.log'):
        m = re.search(r'(\d+x\d+) (Quality|Native), (twelve keyed boxes|moving thin field), internal', l)
        if m and 'xUnit' not in l:
            cur = f'{m.group(1)} {m.group(2)} {"boxes" if "boxes" in m.group(3) else "field"}'; rows[cur] = {}; continue
        if cur is None or 'xUnit' in l: continue
        m = re.search(r'^\s+(single pass|two passes): .*at most (-?[\d.]+) ms', l)
        if m: rows[cur][m.group(1)] = float(m.group(2)); continue
        m = re.search(r'^\s+(pass one|pass two|two passes against the single pass): (-?[\d.]+) ms from the medians, paired round differences median (-?[\d.]+) min (-?[\d.]+) max (-?[\d.]+)', l)
        if m: rows[cur][m.group(1)] = (float(m.group(2)), float(m.group(3)), float(m.group(4)), float(m.group(5)))
    return rows
for cfg in ['2560x1440 Quality boxes', '2560x1440 Quality field', '3456x2234 Quality boxes', '3456x2234 Quality field', '2560x1440 Native boxes', '2560x1440 Native field', '3456x2234 Native boxes', '3456x2234 Native field']:
    print(f'### {cfg}')
    for name, tags in runs.items():
        parts = []
        for t in tags:
            r = parse(t).get(cfg, {})
            if not r: parts.append('n/a'); continue
            d = r['two passes against the single pass']
            parts.append(f"{r['single pass']:.3f}/{r['two passes']:.3f} d{d[1]:+.3f}[{d[2]:+.2f},{d[3]:+.2f}] p1 {r['pass one'][1]:.3f} p2 {r['pass two'][1]:.3f}")
        print(f'  {name:42s} ' + ' | '.join(parts))
