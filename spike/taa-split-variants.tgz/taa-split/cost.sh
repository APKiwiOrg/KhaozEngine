#!/bin/zsh
# usage: cost.sh <tag> [filter suffix]: builds, runs the committed cost test on metal-native, keeps the log, prints the
# load before and after and one summary line per fact and mode
set -u
cd /Users/antonio/KhaozEngine/.worktrees/taa-split
dotnet build KhaozEngine.Render.Tests/KhaozEngine.Render.Tests.csproj -c Release > /tmp/taa-split/cost-$1.build 2>&1 || { echo "build failed"; grep " error " /tmp/taa-split/cost-$1.build | sort -u | head -3; }
L0=$(sysctl -n vm.loadavg)
KE_GPU_TESTS=1 KE_GRAPHICS_BACKEND=metal-native dotnet test KhaozEngine.Render.Tests/KhaozEngine.Render.Tests.csproj -c Release --no-build --filter "FullyQualifiedName~TemporalResolveCostPerf${2:-}" --logger "console;verbosity=detailed" > /tmp/taa-split/cost-$1.log 2>&1
echo "exit $? load before $L0 after $(sysctl -n vm.loadavg)"
python3 /tmp/taa-split/costsum.py /tmp/taa-split/cost-$1.log
