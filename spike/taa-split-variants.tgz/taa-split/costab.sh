#!/bin/zsh
# usage: costab.sh <tag> <rounds> <A.cs> <B.cs>: alternates the resolve source A and B, one cost run each per round,
# then leaves B in place
set -u
W=/Users/antonio/KhaozEngine/.worktrees/taa-split
G=$W/KhaozEngine.Render.Tests/Gpu
S=$W/KhaozEngine.Render3D/Internal/ShaderSources.TemporalResolve.cs
cp /Users/antonio/KhaozEngine/.worktrees/temporal-foundations/.superpowers/sdd/2026-09-24-temporal-aa/task-F15-wip/TemporalResolveCostPerfGpuTests.cs.candidate $G/TemporalResolveCostPerfGpuTests.cs
cd $W
for r in $(seq 1 $2); do
  for v in A B; do
    if [ $v = A ]; then cp $3 $S; else cp $4 $S; fi
    dotnet build KhaozEngine.Render.Tests/KhaozEngine.Render.Tests.csproj -c Release > /tmp/taa-split/costab-$1.build 2>&1 || echo "build failed"
    KE_GPU_TESTS=1 KE_GRAPHICS_BACKEND=metal-native dotnet test KhaozEngine.Render.Tests/KhaozEngine.Render.Tests.csproj -c Release --no-build --filter "FullyQualifiedName~TemporalResolveCostPerf" --logger "console;verbosity=detailed" > /tmp/taa-split/costab-$1-$v$r.log 2>&1
    echo "$v round $r: $(grep -E 'paired round differences' /tmp/taa-split/costab-$1-$v$r.log | grep -v xUnit | sed -E 's/.*median ([0-9.]+) ms.*/\1/' | tr '\n' ' ') load $(sysctl -n vm.loadavg | awk '{print $2}')"
  done
done
cp $4 $S
rm -f $G/TemporalResolveCostPerfGpuTests.cs
[ ! -e $G/TemporalResolveCostPerfGpuTests.cs ] && echo "cost test removed" || echo "COST TEST REMOVE FAILED"
cmp -s $4 $S && echo "B left in place" || echo "B NOT IN PLACE"
dotnet build KhaozEngine.Render.Tests/KhaozEngine.Render.Tests.csproj -c Release > /tmp/taa-split/costab-$1.rebuild 2>&1 && echo "rebuilt" || echo "rebuild failed"
