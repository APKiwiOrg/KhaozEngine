import re, sys
# one line per fact: resolve and sharpen at most for single, split, and the per-pass medians, with paired spreads
cur = None; rows = []
for l in open(sys.argv[1]):
    l = l.rstrip()
    m = re.search(r'(\d+x\d+) (Quality|Native), (twelve keyed boxes|moving thin field), internal (\d+x\d+)', l)
    if m and 'xUnit' not in l: cur = {'k': f'{m.group(1)} {m.group(2)[:4]} {"boxes" if "boxes" in m.group(3) else "field"}'}; rows.append(cur); continue
    if cur is None or 'xUnit' in l: continue
    m = re.search(r'^\s+(single pass|two passes|pass one alone|pass two alone): .*at most (-?[\d.]+) ms, paired round differences median (-?[\d.]+) min (-?[\d.]+) max (-?[\d.]+)', l)
    if m: cur[m.group(1)] = (float(m.group(2)), float(m.group(4)), float(m.group(5))); continue
    m = re.search(r'^\s+(pass one|pass two|two passes against the single pass): (-?[\d.]+) ms from the medians, paired round differences median (-?[\d.]+) min (-?[\d.]+) max (-?[\d.]+)', l)
    if m: cur[m.group(1)] = (float(m.group(2)), float(m.group(4)), float(m.group(5)))
def f(t): return f'{t[0]:.3f} ({t[1]:.2f}..{t[2]:.2f})' if t else 'n/a'
print(f'{"config":22s} {"single":20s} {"split":20s} {"split-single":20s} {"pass one":20s} {"pass two":20s}')
for r in rows:
    print(f'{r["k"]:22s} {f(r.get("single pass")):20s} {f(r.get("two passes")):20s} {f(r.get("two passes against the single pass")):20s} {f(r.get("pass one")):20s} {f(r.get("pass two")):20s}')
