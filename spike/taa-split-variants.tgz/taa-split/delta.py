import re, sys
from collections import defaultdict
# usage: delta.py base.printed other.printed [top]: moved printed lines, paired by test and by the line with its numbers
# masked, ranked by the largest relative move of any number on the line
NUM = re.compile(r'-?\d+\.\d+|-?\d+')
def load(p):
    d = defaultdict(list)
    for l in open(p):
        l = l.rstrip('\n')
        if ' :: ' not in l: continue
        t, x = l.split(' :: ', 1)
        if x.startswith('at ') or 'Stack Trace' in x or x.startswith('the box leaves') and False: pass
        d[(t, NUM.sub('#', x))].append(x)
    return d
a, b = load(sys.argv[1]), load(sys.argv[2])
top = int(sys.argv[3]) if len(sys.argv) > 3 else 25
moved = []; unpaired_a = unpaired_b = 0; same = 0
for k in set(a) | set(b):
    la, lb = a.get(k, []), b.get(k, [])
    for i in range(max(len(la), len(lb))):
        if i >= len(la): unpaired_b += 1; continue
        if i >= len(lb): unpaired_a += 1; continue
        if la[i] == lb[i]: same += 1; continue
        na = [float(x) for x in NUM.findall(la[i])]; nb = [float(x) for x in NUM.findall(lb[i])]
        worst = 0.0; where = ''
        for j, (x, y) in enumerate(zip(na, nb)):
            if x == y: continue
            rel = abs(y - x) / max(abs(x), abs(y), 1e-3)
            if rel > worst: worst, where = rel, f'{x:g} -> {y:g}'
        moved.append((worst, k[0], where, la[i], lb[i]))
print(f'same {same}, moved {len(moved)}, only in base {unpaired_a}, only in other {unpaired_b}')
moved.sort(reverse=True)
tests = defaultdict(int)
for m in moved: tests[m[1].split('(')[0]] += 1
print('moved lines by fact:')
for t, n in sorted(tests.items(), key=lambda x: -x[1]): print(f'  {n:4d} {t}')
print(f'top {top} by relative move:')
for w, t, where, x, y in moved[:top]:
    print(f'  {w:.3f} {t[:110]}\n      {where}\n      base  {x[:230]}\n      other {y[:230]}')
