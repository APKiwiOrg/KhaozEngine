#!/bin/zsh
# usage: gates.sh <tag> [filter]: temporal GPU facts on metal-native, detailed, full acceptance table, printed lines parsed
set -u
cd /Users/antonio/KhaozEngine/.worktrees/taa-split
F=${2:-"FullyQualifiedName~Temporal&FullyQualifiedName!~TemporalResolveCostPerf"}
dotnet build KhaozEngine.Render.Tests/KhaozEngine.Render.Tests.csproj -c Release > /tmp/taa-split/gates-$1.build 2>&1 || { echo "build failed"; grep -E " error " /tmp/taa-split/gates-$1.build | sort -u | head; }
KE_TEMPORAL_ACCEPTANCE_TABLE=1 KE_GPU_TESTS=1 KE_GRAPHICS_BACKEND=metal-native dotnet test KhaozEngine.Render.Tests/KhaozEngine.Render.Tests.csproj -c Release --no-build --filter "$F" --logger "console;verbosity=detailed" > /tmp/taa-split/gates-$1.log 2>&1
echo "exit $?"
grep -E "^\s+(Passed|Failed|Skipped) KhaozEngine" /tmp/taa-split/gates-$1.log | sed -E 's/ \[[^]]*\]$//' | sort > /tmp/taa-split/gates-$1.results
echo "passed $(grep -c '^\s*Passed' /tmp/taa-split/gates-$1.results) failed $(grep -c '^\s*Failed' /tmp/taa-split/gates-$1.results) skipped $(grep -c '^\s*Skipped' /tmp/taa-split/gates-$1.results)"
grep "^\s*Failed" /tmp/taa-split/gates-$1.results
python3 /tmp/taa-split/printed.py /tmp/taa-split/gates-$1.log > /tmp/taa-split/gates-$1.printed
echo "printed lines $(wc -l < /tmp/taa-split/gates-$1.printed)"
