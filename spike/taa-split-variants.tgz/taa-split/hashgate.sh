#!/bin/zsh
# usage: hashgate.sh <tag> [filter]: swaps in the scratch hash hooks, runs the temporal GPU facts (or the filter), restores
# the committed files, rebuilds, and sorts the per-owner hashes of every resolved frame's outputs
set -u
W=/Users/antonio/KhaozEngine/.worktrees/taa-split
G=$W/KhaozEngine.Render.Tests/Gpu
H=/tmp/taa-split/hook
F=${2:-"FullyQualifiedName~Temporal&FullyQualifiedName!~TemporalResolveCostPerf&FullyQualifiedName!~Allocation"}
cp $G/TemporalFixture.cs $H/TemporalFixture.live.cs
cp $G/TemporalResolveRig.cs $H/TemporalResolveRig.live.cs
diff -q $H/TemporalFixture.live.cs $H/TemporalFixture.orig.cs >/dev/null && diff -q $H/TemporalResolveRig.live.cs $H/TemporalResolveRig.orig.cs >/dev/null || { echo "hook base differs from the live files"; exit 3; }
cp $H/ScratchResolveHash.cs $G/ScratchResolveHash.cs
cp $H/TemporalFixture.hooked.cs $G/TemporalFixture.cs
cp $H/TemporalResolveRig.hooked.cs $G/TemporalResolveRig.cs
cd $W
dotnet build KhaozEngine.Render.Tests/KhaozEngine.Render.Tests.csproj -c Release > /tmp/taa-split/hash-$1.build 2>&1 || echo "hooked build failed"
rm -f /tmp/taa-split/hash-$1.raw
KE_SCRATCH_HASH_FILE=/tmp/taa-split/hash-$1.raw KE_TEMPORAL_ACCEPTANCE_TABLE=1 KE_GPU_TESTS=1 KE_GRAPHICS_BACKEND=metal-native dotnet test KhaozEngine.Render.Tests/KhaozEngine.Render.Tests.csproj -c Release --no-build --filter "$F" > /tmp/taa-split/hash-$1.log 2>&1
echo "test exit $?"
grep -E "Passed!|Failed!" /tmp/taa-split/hash-$1.log | sed -E 's/ - .*//'
cp $H/TemporalFixture.orig.cs $G/TemporalFixture.cs
cp $H/TemporalResolveRig.orig.cs $G/TemporalResolveRig.cs
rm -f $G/ScratchResolveHash.cs
git diff --quiet -- $G/TemporalFixture.cs $G/TemporalResolveRig.cs && [ ! -e $G/ScratchResolveHash.cs ] && echo "hooks removed" || echo "HOOK RESTORE FAILED"
dotnet build KhaozEngine.Render.Tests/KhaozEngine.Render.Tests.csproj -c Release > /tmp/taa-split/hash-$1.rebuild 2>&1 && echo "rebuilt unhooked" || echo "unhooked rebuild failed"
sort /tmp/taa-split/hash-$1.raw > /tmp/taa-split/hash-$1.txt
echo "owners $(wc -l < /tmp/taa-split/hash-$1.txt), frames $(awk '{s+=$4} END {print s}' /tmp/taa-split/hash-$1.txt)"
