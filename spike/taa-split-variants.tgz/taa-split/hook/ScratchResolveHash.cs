using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using KhaozEngine.Gpu;
using KhaozEngine.Render3D.Internal;

namespace KhaozEngine.Tests.Gpu
{
    // Scratch only, never committed: hashes the resolve's two display outputs after every resolved frame, per owner,
    // and appends one line per owner on dispose to the file named by KE_SCRATCH_HASH_FILE, named by the test on the
    // stack at the owner's first resolved frame.
    internal static class ScratchResolveHash
    {
        sealed class State
        {
            public readonly IncrementalHash Hash = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
            public int Frames;
            public string Size = "";
            public string Name = "";
        }

        static readonly ConditionalWeakTable<object, State> States = new();
        static readonly object Gate = new();
        static readonly string? Path = Environment.GetEnvironmentVariable("KE_SCRATCH_HASH_FILE");

        static string TestName()
        {
            string runs = "", test = "unknown";
            foreach (StackFrame f in new StackTrace().GetFrames())
            {
                var m = f.GetMethod();
                Type? t = m?.DeclaringType;
                while (t != null && t.Name.StartsWith('<')) t = t.DeclaringType;
                if (t == null) continue;
                if (runs.Length == 0 && t.Name.EndsWith("Runs", StringComparison.Ordinal)) runs = t.Name;
                if (t.Name.EndsWith("Tests", StringComparison.Ordinal)) test = t.Name + "." + m!.Name;
            }
            return test + "/" + runs;
        }

        public static void Record(object owner, IGpuDevice gd, TemporalHistory history)
        {
            if (Path is null || !history.TargetsAllocated) return;
            State s = States.GetOrCreateValue(owner);
            if (s.Frames == 0) s.Name = TestName();
            float[] color = TemporalTextureIo.Read(gd, history.Color(history.WriteIndex));
            float[] state = TemporalTextureIo.Read(gd, history.Confidence(history.WriteIndex));
            s.Hash.AppendData(MemoryMarshal.AsBytes(color.AsSpan()));
            s.Hash.AppendData(MemoryMarshal.AsBytes(state.AsSpan()));
            s.Frames++;
            s.Size = history.DisplayWidth + "x" + history.DisplayHeight;
        }

        public static void Flush(object owner)
        {
            if (Path is null || !States.TryGetValue(owner, out State? s)) return;
            string line = s.Name + " " + Convert.ToHexStringLower(s.Hash.GetHashAndReset()) + " frames " + s.Frames
                + " size " + s.Size;
            lock (Gate) File.AppendAllText(Path, line + "\n");
            States.Remove(owner);
        }
    }
}
