# builds the exact 32-bit target variant of the split under /tmp/taa-split/var-exact from the pristine copies
import os
O='/tmp/taa-split/orig/'; V='/tmp/taa-split/var-exact/'
def rep(s,a,b,n=1):
    assert s.count(a)==n,(a,s.count(a)); return s.replace(a,b)
# pass one
s=open(O+'ShaderSources.TemporalSplit.cs').read()
s=rep(s,'''layout(location=0) out vec4 oPrepared;    // weighted YCoCg, alpha
layout(location=1) out vec4 oReproject;   // reactive difference, the chosen motion, the flags
layout(location=2) out vec4 oExpected;    // the expected depth of the surface the pixel reprojects by
layout(location=3) out vec4 oEdge;        // the lock's edge release
layout(location=4) out vec4 oDepth;       // this frame's view depth, the depth store's value''',
'''layout(location=0) out vec4 oY;
layout(location=1) out vec4 oCo;
layout(location=2) out vec4 oCg;
layout(location=3) out vec4 oReactive;
layout(location=4) out vec4 oReproject;   // alpha, the chosen motion, the flags
layout(location=5) out vec4 oExpected;
layout(location=6) out vec4 oEdge;
layout(location=7) out vec4 oDepth;''')
s=rep(s,'''    oPrepared = vec4(rgbToYCoCg(weightedColor), sceneColor.a);
    oReproject = vec4(reactiveDifference, chosenMotion, float(flags));''',
'''    vec3 preparedYcc = rgbToYCoCg(weightedColor);
    oY = vec4(preparedYcc.x, 0.0, 0.0, 1.0);
    oCo = vec4(preparedYcc.y, 0.0, 0.0, 1.0);
    oCg = vec4(preparedYcc.z, 0.0, 0.0, 1.0);
    oReactive = vec4(reactiveDifference, 0.0, 0.0, 1.0);
    oReproject = vec4(sceneColor.a, chosenMotion, float(flags));''')
open(V+'ShaderSources.TemporalSplit.cs','w').write(s)
# pass two
s=open(O+'ShaderSources.TemporalSplitResolve.cs').read()
s=rep(s,'''layout(set=0, binding=0) uniform texture2D Prepared;
layout(set=0, binding=1) uniform texture2D PreparedReproject;
layout(set=0, binding=2) uniform texture2D PreparedExpected;
layout(set=0, binding=3) uniform texture2D PreparedEdge;
layout(set=0, binding=4) uniform texture2D CurrentViewDepth;
layout(set=0, binding=5) uniform texture2D PrevDepth;
layout(set=0, binding=6) uniform texture2D HistoryColor;
layout(set=0, binding=7) uniform texture2D HistoryConfidence;
layout(set=0, binding=8) uniform sampler LinearClamp;
// The members are TemporalResolveUniforms.GlslMembers, documented on the struct's fields.
layout(set=0, binding=9) uniform Resolve {" + TemporalResolveUniforms.GlslMembers + @"};
''','''layout(set=0, binding=0) uniform texture2D PreparedY;
layout(set=0, binding=1) uniform texture2D PreparedCo;
layout(set=0, binding=2) uniform texture2D PreparedCg;
layout(set=0, binding=3) uniform texture2D PreparedReactive;
layout(set=0, binding=4) uniform texture2D PreparedReproject;
layout(set=0, binding=5) uniform texture2D PreparedExpected;
layout(set=0, binding=6) uniform texture2D PreparedEdge;
layout(set=0, binding=7) uniform texture2D CurrentViewDepth;
layout(set=0, binding=8) uniform texture2D PrevDepth;
layout(set=0, binding=9) uniform texture2D HistoryColor;
layout(set=0, binding=10) uniform texture2D HistoryConfidence;
layout(set=0, binding=11) uniform sampler LinearClamp;
layout(set=0, binding=12) uniform Resolve {" + TemporalResolveUniforms.GlslMembers + @"};
vec4 splitPrepared(ivec2 t) {
    return vec4(texelFetch(sampler2D(PreparedY, LinearClamp), t, 0).r, texelFetch(sampler2D(PreparedCo, LinearClamp), t, 0).r,
        texelFetch(sampler2D(PreparedCg, LinearClamp), t, 0).r, texelFetch(sampler2D(PreparedReproject, LinearClamp), t, 0).x);
}
float splitReactive(ivec2 t) { return texelFetch(sampler2D(PreparedReactive, LinearClamp), t, 0).r; }
''')
s=rep(s,'texelFetch(sampler2D(Prepared, LinearClamp), nextTexel, 0)','splitPrepared(nextTexel)',2)
s=rep(s,'texelFetch(sampler2D(PreparedReproject, LinearClamp), nextTexel, 0).x','splitReactive(nextTexel)',2)
s=rep(s,'texelFetch(sampler2D(Prepared, LinearClamp), texel, 0)','splitPrepared(texel)',1)
open(V+'ShaderSources.TemporalSplitResolve.cs','w').write(s)
# formats unchanged file (the variant's formats live in the renderer copy)
open(V+'TemporalSplitFormats.cs','w').write(open(O+'TemporalSplitFormats.cs').read())
# renderer
s=open(O+'TemporalSplitResolve.cs').read()
s=rep(s,'''                T("Prepared"), T("PreparedReproject"), T("PreparedExpected"), T("PreparedEdge"), T("CurrentViewDepth"),''',
'''                T("PreparedY"), T("PreparedCo"), T("PreparedCg"), T("PreparedReactive"), T("PreparedReproject"),
                T("PreparedExpected"), T("PreparedEdge"), T("CurrentViewDepth"),''')
s=rep(s,'''                new GpuOutputDescription(null, TemporalSplitFormats.Prepared, TemporalSplitFormats.Reproject,
                    TemporalSplitFormats.Expected, TemporalSplitFormats.Edge, TemporalFormats.PreviousDepth));''',
'''                new GpuOutputDescription(null, GpuPixelFormat.R32Float, GpuPixelFormat.R32Float, GpuPixelFormat.R32Float,
                    GpuPixelFormat.R32Float, TemporalSplitFormats.Reproject,
                    TemporalSplitFormats.Expected, TemporalSplitFormats.Edge, TemporalFormats.PreviousDepth));''')
s=rep(s,'        IGpuTexture? _prepared, _reproject, _expected, _edge;','        IGpuTexture? _prepared, _reproject, _expected, _edge, _co, _cg, _reactive;')
s=rep(s,'''                _prepared = Target(f, TemporalSplitFormats.Prepared);''','''                _prepared = Target(f, GpuPixelFormat.R32Float);
                _co = Target(f, GpuPixelFormat.R32Float);
                _cg = Target(f, GpuPixelFormat.R32Float);
                _reactive = Target(f, GpuPixelFormat.R32Float);''')
s=rep(s,'''                _prepareFramebuffers[i] = f.CreateFramebuffer(null, _prepared, _reproject!, _expected!, _edge!,''',
'''                _prepareFramebuffers[i] = f.CreateFramebuffer(null, _prepared, _co!, _cg!, _reactive!, _reproject!, _expected!, _edge!,''')
s=rep(s,'''                    _prepared, _reproject!, _expected!, _edge!, history.PreviousDepth(1 - i), history.PreviousDepth(i),''',
'''                    _prepared, _co!, _cg!, _reactive!, _reproject!, _expected!, _edge!, history.PreviousDepth(1 - i), history.PreviousDepth(i),''')
s=rep(s,'''            _prepared = _reproject = _expected = _edge = null;''','''            _co?.Dispose();
            _cg?.Dispose();
            _reactive?.Dispose();
            _prepared = _reproject = _expected = _edge = _co = _cg = _reactive = null;''')
open(V+'TemporalSplitResolve.cs','w').write(s)
print('exact variant written')
