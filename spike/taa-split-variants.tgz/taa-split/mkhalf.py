# usage: mkhalf.py <name> <base dir>: the base variant with pass two's colour, statistics, history and clip math in half
import sys, os, shutil
name, base = sys.argv[1], sys.argv[2]
B = '/tmp/taa-split/' + base + '/'; V = '/tmp/taa-split/' + name + '/'
os.makedirs(V, exist_ok=True)
for f in os.listdir(B): shutil.copy(B + f, V + f)
p = V + 'ShaderSources.TemporalSplitResolve.cs'
s = open(p).read()
def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (a[:70], s.count(a)); s = s.replace(a, b)
rep('public const string TemporalSplitFrag = "#version 450\\n" + TemporalSplitBindingsGlsl',
    'public const string TemporalSplitFrag = "#version 450\\n#extension GL_EXT_shader_explicit_arithmetic_types_float16 : require\\n" + TemporalSplitBindingsGlsl')
# half overloads of the colour helpers
rep('''bool isRidge(float centreLuma, float a, float b, float threshold) {''', '''float16_t hLuma(f16vec3 c) { return dot(c, f16vec3(0.2126hf, 0.7152hf, 0.0722hf)); }
f16vec3 hToWeighted(f16vec3 c) { return c / (float16_t(1.0) + hLuma(c)); }
f16vec3 hFromWeighted(f16vec3 w) { return w / max(float16_t(1.0) - hLuma(w), float16_t(1.0e-4)); }
f16vec3 hRgbToYCoCg(f16vec3 c) {
    return f16vec3(0.25hf * c.r + 0.5hf * c.g + 0.25hf * c.b, 0.5hf * c.r - 0.5hf * c.b, -0.25hf * c.r + 0.5hf * c.g - 0.25hf * c.b);
}
f16vec3 hYCoCgToRgb(f16vec3 c) { return f16vec3(c.x + c.y - c.z, c.x + c.z, c.x - c.y - c.z); }
bool hIsRidge(float16_t centreLuma, float16_t a, float16_t b, float16_t threshold) {
    return centreLuma - max(a, b) > threshold || min(a, b) - centreLuma > threshold;
}
bool isRidge(float centreLuma, float a, float b, float threshold) {''')
# the 3x3 accumulators
rep('''    vec3 momentSum = vec3(0.0);
    vec3 momentSquares = vec3(0.0);
    vec3 neighbourMin = vec3(1.0e30);
    vec3 neighbourMax = vec3(-1.0e30);
    float alphaMin = 1.0e30;
    float alphaMax = -1.0e30;
    vec4 reconstruction = vec4(0.0);
    float reconstructionWeight = 0.0;
    float sampleWeight = 0.0;
    float reactiveDifference = 0.0;
    float lumas[9];''', '''    f16vec3 momentSum = f16vec3(0.0);
    f16vec3 momentSquares = f16vec3(0.0);
    f16vec3 neighbourMin = f16vec3(60000.0);
    f16vec3 neighbourMax = f16vec3(-60000.0);
    float16_t alphaMin = float16_t(60000.0);
    float16_t alphaMax = float16_t(-60000.0);
    f16vec4 reconstruction = f16vec4(0.0);
    float16_t reconstructionWeight = float16_t(0.0);
    float16_t sampleWeight = float16_t(0.0);
    float16_t reactiveDifference = float16_t(0.0);
    float16_t lumas[9];''')
rep('''    vec3 kernelX = vec3(0.0);
    vec3 kernelY = vec3(0.0);
    vec3 displayKernelX = vec3(0.0);
    vec3 displayKernelY = vec3(0.0);''', '''    f16vec3 kernelX = f16vec3(0.0);
    f16vec3 kernelY = f16vec3(0.0);
    f16vec3 displayKernelX = f16vec3(0.0);
    f16vec3 displayKernelY = f16vec3(0.0);''')
rep('''        kernelX[i] = lanczos2(toSample.x);
        kernelY[i] = lanczos2(toSample.y);
        displayKernelX[i] = lanczos2(toSample.x * displayOverInternal);
        displayKernelY[i] = lanczos2(toSample.y * displayOverInternal);''', '''        kernelX[i] = float16_t(lanczos2(toSample.x));
        kernelY[i] = float16_t(lanczos2(toSample.y));
        displayKernelX[i] = float16_t(lanczos2(toSample.x * displayOverInternal));
        displayKernelY[i] = float16_t(lanczos2(toSample.y * displayOverInternal));''')
rep('''    vec4 nextPrepared = texelFetch(sampler2D(Prepared, LinearClamp), nextTexel, 0);
    float nextReactive = texelFetch(sampler2D(PreparedReproject, LinearClamp), nextTexel, 0).x;''',
'''    f16vec4 nextPrepared = f16vec4(texelFetch(sampler2D(Prepared, LinearClamp), nextTexel, 0));
    float16_t nextReactive = float16_t(texelFetch(sampler2D(PreparedReproject, LinearClamp), nextTexel, 0).x);''')
rep('''            vec4 prepared = nextPrepared;
            float texelReactive = nextReactive;''', '''            f16vec4 prepared = nextPrepared;
            float16_t texelReactive = nextReactive;''')
rep('''            nextPrepared = texelFetch(sampler2D(Prepared, LinearClamp), nextTexel, 0);
            nextReactive = texelFetch(sampler2D(PreparedReproject, LinearClamp), nextTexel, 0).x;
            vec3 ycc = prepared.xyz;''', '''            nextPrepared = f16vec4(texelFetch(sampler2D(Prepared, LinearClamp), nextTexel, 0));
            nextReactive = float16_t(texelFetch(sampler2D(PreparedReproject, LinearClamp), nextTexel, 0).x);
            f16vec3 ycc = prepared.xyz;''')
rep('''            float lanczosWeight = kernelX[x + 1] * kernelY[y + 1];
            reconstruction += vec4(ycc, prepared.w) * lanczosWeight;
            reconstructionWeight += lanczosWeight;
            sampleWeight = max(sampleWeight, clamp(displayKernelX[x + 1] * displayKernelY[y + 1], 0.0, 1.0));''',
'''            float16_t lanczosWeight = kernelX[x + 1] * kernelY[y + 1];
            reconstruction += f16vec4(ycc, prepared.w) * lanczosWeight;
            reconstructionWeight += lanczosWeight;
            sampleWeight = max(sampleWeight, clamp(displayKernelX[x + 1] * displayKernelY[y + 1], float16_t(0.0), float16_t(1.0)));''')
rep('''    float reactive = clamp(reactiveDifference * ReactiveGain, 0.0, 1.0);
    vec3 mean = momentSum / 9.0;
    vec3 deviation = sqrt(max(momentSquares / 9.0 - mean * mean, vec3(0.0)));
    vec4 current = reconstruction / max(reconstructionWeight, 1.0e-4);''', '''    float reactive = clamp(float(reactiveDifference) * ReactiveGain, 0.0, 1.0);
    f16vec3 mean = momentSum / float16_t(9.0);
    f16vec3 deviation = sqrt(max(momentSquares / float16_t(9.0) - mean * mean, f16vec3(0.0)));
    f16vec4 current = reconstruction / max(reconstructionWeight, float16_t(1.0e-4));''')
# history and clip
rep('''    vec4 history = vec4(0.0);
    vec2 historyState = vec2(0.0);''', '''    f16vec4 history = f16vec4(0.0);
    vec2 historyState = vec2(0.0);''')
rep('''            history = max(fetched, vec4(0.0));''', '''            history = f16vec4(max(fetched, vec4(0.0)));''')
rep('''    float centreLuma = lumas[4];
    float ridgeThreshold = max(LockRidgeAbsolute, LockRidgeRelative * centreLuma);
    bool ridge = isRidge(centreLuma, lumas[3], lumas[5], ridgeThreshold)
        || isRidge(centreLuma, lumas[1], lumas[7], ridgeThreshold)
        || isRidge(centreLuma, lumas[0], lumas[8], ridgeThreshold)
        || isRidge(centreLuma, lumas[2], lumas[6], ridgeThreshold);''', '''    float16_t centreLuma = lumas[4];
    float16_t ridgeThreshold = max(float16_t(LockRidgeAbsolute), float16_t(LockRidgeRelative) * centreLuma);
    bool ridge = hIsRidge(centreLuma, lumas[3], lumas[5], ridgeThreshold)
        || hIsRidge(centreLuma, lumas[1], lumas[7], ridgeThreshold)
        || hIsRidge(centreLuma, lumas[0], lumas[8], ridgeThreshold)
        || hIsRidge(centreLuma, lumas[2], lumas[6], ridgeThreshold);''')
rep('''    float gamma = mix(GammaStill, GammaMoving, clamp(motionPixels / GammaMotionPixels, 0.0, 1.0));
    vec3 boxMin = mean - gamma * deviation;
    vec3 boxMax = mean + gamma * deviation;
    vec3 historyYcc = rgbToYCoCg(toWeighted(history.rgb));
    vec3 boxCentre = 0.5 * (boxMin + boxMax);
    vec3 boxExtent = 0.5 * (boxMax - boxMin) + vec3(1.0e-5);
    vec3 fromCentre = historyYcc - boxCentre;
    vec3 excess = abs(fromCentre) / boxExtent;
    excess.x *= 1.0 - hold;
    float clipScale = max(excess.x, max(excess.y, excess.z));
    vec3 clipped = clipScale > 1.0 ? boxCentre + fromCentre / clipScale : historyYcc;
    clipped.x = mix(clipped.x, historyYcc.x, hold);
    float historyAlpha = clamp(history.a, alphaMin, alphaMax);''', '''    float16_t gamma = float16_t(mix(GammaStill, GammaMoving, clamp(motionPixels / GammaMotionPixels, 0.0, 1.0)));
    float16_t hHold = float16_t(hold);
    f16vec3 boxMin = mean - gamma * deviation;
    f16vec3 boxMax = mean + gamma * deviation;
    f16vec3 historyYcc = hRgbToYCoCg(hToWeighted(history.rgb));
    f16vec3 boxCentre = float16_t(0.5) * (boxMin + boxMax);
    f16vec3 boxExtent = float16_t(0.5) * (boxMax - boxMin) + f16vec3(6.0e-5);
    f16vec3 fromCentre = historyYcc - boxCentre;
    f16vec3 excess = abs(fromCentre) / boxExtent;
    excess.x *= float16_t(1.0) - hHold;
    float16_t clipScale = max(excess.x, max(excess.y, excess.z));
    f16vec3 clipped = clipScale > float16_t(1.0) ? boxCentre + fromCentre / clipScale : historyYcc;
    clipped.x = mix(clipped.x, historyYcc.x, hHold);
    float16_t historyAlpha = clamp(history.a, alphaMin, alphaMax);''')
# the moving share
rep('''        vec4 nearerSum = vec4(0.0);
        float nearerWeight = 0.0;''', '''        f16vec4 nearerSum = f16vec4(0.0);
        float16_t nearerWeight = float16_t(0.0);''')
rep('''                vec4 prepared = texelFetch(sampler2D(Prepared, LinearClamp), texel, 0);
                float lanczosWeight = kernelX[x + 1] * kernelY[y + 1];''', '''                f16vec4 prepared = f16vec4(texelFetch(sampler2D(Prepared, LinearClamp), texel, 0));
                float16_t lanczosWeight = kernelX[x + 1] * kernelY[y + 1];''')
rep('''        if (nearerWeight > 1.0e-4) {
            movingShare = clamp(nearerWeight / max(reconstructionWeight, 1.0e-4), 0.0, 1.0) * (1.0 - hold);
            vec4 movingColor = nearerSum / nearerWeight;
            clipped = mix(clipped, clamp(movingColor.xyz, neighbourMin, neighbourMax), movingShare);
            historyAlpha = mix(historyAlpha, clamp(movingColor.w, alphaMin, alphaMax), movingShare);''', '''        if (nearerWeight > float16_t(1.0e-4)) {
            movingShare = clamp(float(nearerWeight) / max(float(reconstructionWeight), 1.0e-4), 0.0, 1.0) * (1.0 - hold);
            f16vec4 movingColor = nearerSum / nearerWeight;
            clipped = mix(clipped, clamp(movingColor.xyz, neighbourMin, neighbourMax), float16_t(movingShare));
            historyAlpha = mix(historyAlpha, clamp(movingColor.w, alphaMin, alphaMax), float16_t(movingShare));''')
rep('''    float currentWeight = accumulated > 1.0e-3 ? sampleWeight / (accumulated + sampleWeight) : 1.0;
    vec3 resolvedYcc = mix(clipped, current.xyz, currentWeight);

    TemporalPixel result;
    result.color = fromWeighted(max(yCoCgToRgb(resolvedYcc), vec3(0.0)));
    result.alpha = mix(historyAlpha, current.w, currentWeight);''', '''    float currentWeight = accumulated > 1.0e-3 ? float(sampleWeight) / (accumulated + float(sampleWeight)) : 1.0;
    f16vec3 resolvedYcc = mix(clipped, current.xyz, float16_t(currentWeight));

    TemporalPixel result;
    result.color = vec3(hFromWeighted(max(hYCoCgToRgb(resolvedYcc), f16vec3(0.0))));
    result.alpha = float(mix(historyAlpha, current.w, float16_t(currentWeight)));''')
rep('''    result.clip = useHistory && clipScale > 1.0 && length(clipped - historyYcc) > ClipFlagMinimumMove ? 1.0 : 0.0;''',
'''    result.clip = useHistory && clipScale > float16_t(1.0) && length(vec3(clipped - historyYcc)) > ClipFlagMinimumMove ? 1.0 : 0.0;''')
open(p, 'w').write(s)
print('half variant', name, 'from', base)
