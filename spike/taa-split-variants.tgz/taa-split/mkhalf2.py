# usage: mkhalf2.py <name> <base dir>: pass two's 3x3 (kernels, prepared colour, min and max, alpha, reconstruction,
# lumas, reactive) in half, the moments, clip, moving share and blend in float
import sys, os, shutil
name, base = sys.argv[1], sys.argv[2]
B = '/tmp/taa-split/' + base + '/'; V = '/tmp/taa-split/' + name + '/'
os.makedirs(V, exist_ok=True)
for f in os.listdir(B): shutil.copy(B + f, V + f)
p = V + 'ShaderSources.TemporalSplitResolve.cs'
s = open(p).read()
def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (a[:70], s.count(a)); s = s.replace(a, b)
rep('public const string TemporalSplitFrag = "#version 450\\n" + TemporalSplitBindingsGlsl',
    'public const string TemporalSplitFrag = "#version 450\\n#extension GL_EXT_shader_explicit_arithmetic_types_float16 : require\\n" + TemporalSplitBindingsGlsl')
rep('''bool isRidge(float centreLuma, float a, float b, float threshold) {''', '''bool hIsRidge(float16_t centreLuma, float16_t a, float16_t b, float16_t threshold) {
    return centreLuma - max(a, b) > threshold || min(a, b) - centreLuma > threshold;
}
bool isRidge(float centreLuma, float a, float b, float threshold) {''')
rep('''    vec3 neighbourMin = vec3(1.0e30);
    vec3 neighbourMax = vec3(-1.0e30);
    float alphaMin = 1.0e30;
    float alphaMax = -1.0e30;
    vec4 reconstruction = vec4(0.0);
    float reconstructionWeight = 0.0;
    float sampleWeight = 0.0;
    float reactiveDifference = 0.0;
    float lumas[9];''', '''    f16vec3 neighbourMin = f16vec3(60000.0);
    f16vec3 neighbourMax = f16vec3(-60000.0);
    float16_t alphaMin = float16_t(60000.0);
    float16_t alphaMax = float16_t(-60000.0);
    f16vec4 reconstruction = f16vec4(0.0);
    float16_t reconstructionWeight = float16_t(0.0);
    float16_t sampleWeight = float16_t(0.0);
    float16_t reactiveDifference = float16_t(0.0);
    float16_t lumas[9];''')
rep('''    vec3 kernelX = vec3(0.0);
    vec3 kernelY = vec3(0.0);
    vec3 displayKernelX = vec3(0.0);
    vec3 displayKernelY = vec3(0.0);''', '''    f16vec3 kernelX = f16vec3(0.0);
    f16vec3 kernelY = f16vec3(0.0);
    f16vec3 displayKernelX = f16vec3(0.0);
    f16vec3 displayKernelY = f16vec3(0.0);''')
rep('''        kernelX[i] = lanczos2(toSample.x);
        kernelY[i] = lanczos2(toSample.y);
        displayKernelX[i] = lanczos2(toSample.x * displayOverInternal);
        displayKernelY[i] = lanczos2(toSample.y * displayOverInternal);''', '''        kernelX[i] = float16_t(lanczos2(toSample.x));
        kernelY[i] = float16_t(lanczos2(toSample.y));
        displayKernelX[i] = float16_t(lanczos2(toSample.x * displayOverInternal));
        displayKernelY[i] = float16_t(lanczos2(toSample.y * displayOverInternal));''')
rep('''    vec4 nextPrepared = texelFetch(sampler2D(Prepared, LinearClamp), nextTexel, 0);
    float nextReactive = texelFetch(sampler2D(PreparedReproject, LinearClamp), nextTexel, 0).x;''',
'''    f16vec4 nextPrepared = f16vec4(texelFetch(sampler2D(Prepared, LinearClamp), nextTexel, 0));
    float16_t nextReactive = float16_t(texelFetch(sampler2D(PreparedReproject, LinearClamp), nextTexel, 0).x);''')
rep('''            vec4 prepared = nextPrepared;
            float texelReactive = nextReactive;''', '''            f16vec4 prepared = nextPrepared;
            float16_t texelReactive = nextReactive;''')
rep('''            nextPrepared = texelFetch(sampler2D(Prepared, LinearClamp), nextTexel, 0);
            nextReactive = texelFetch(sampler2D(PreparedReproject, LinearClamp), nextTexel, 0).x;
            vec3 ycc = prepared.xyz;
            lumas[(y + 1) * 3 + (x + 1)] = ycc.x;
            momentSum += ycc;
            momentSquares += ycc * ycc;''', '''            nextPrepared = f16vec4(texelFetch(sampler2D(Prepared, LinearClamp), nextTexel, 0));
            nextReactive = float16_t(texelFetch(sampler2D(PreparedReproject, LinearClamp), nextTexel, 0).x);
            f16vec3 ycc = prepared.xyz;
            lumas[(y + 1) * 3 + (x + 1)] = ycc.x;
            vec3 fullYcc = vec3(ycc);
            momentSum += fullYcc;
            momentSquares += fullYcc * fullYcc;''')
rep('''            float lanczosWeight = kernelX[x + 1] * kernelY[y + 1];
            reconstruction += vec4(ycc, prepared.w) * lanczosWeight;
            reconstructionWeight += lanczosWeight;
            sampleWeight = max(sampleWeight, clamp(displayKernelX[x + 1] * displayKernelY[y + 1], 0.0, 1.0));''',
'''            float16_t lanczosWeight = kernelX[x + 1] * kernelY[y + 1];
            reconstruction += f16vec4(ycc, prepared.w) * lanczosWeight;
            reconstructionWeight += lanczosWeight;
            sampleWeight = max(sampleWeight, clamp(displayKernelX[x + 1] * displayKernelY[y + 1], float16_t(0.0), float16_t(1.0)));''')
rep('''    float reactive = clamp(reactiveDifference * ReactiveGain, 0.0, 1.0);''', '''    float reactive = clamp(float(reactiveDifference) * ReactiveGain, 0.0, 1.0);''')
rep('''    vec4 current = reconstruction / max(reconstructionWeight, 1.0e-4);
    current.xyz = clamp(current.xyz, neighbourMin, neighbourMax);
    current.w = clamp(current.w, alphaMin, alphaMax);''', '''    vec4 current = vec4(reconstruction) / max(float(reconstructionWeight), 1.0e-4);
    current.xyz = clamp(current.xyz, vec3(neighbourMin), vec3(neighbourMax));
    current.w = clamp(current.w, float(alphaMin), float(alphaMax));''')
rep('''    float centreLuma = lumas[4];
    float ridgeThreshold = max(LockRidgeAbsolute, LockRidgeRelative * centreLuma);
    bool ridge = isRidge(centreLuma, lumas[3], lumas[5], ridgeThreshold)
        || isRidge(centreLuma, lumas[1], lumas[7], ridgeThreshold)
        || isRidge(centreLuma, lumas[0], lumas[8], ridgeThreshold)
        || isRidge(centreLuma, lumas[2], lumas[6], ridgeThreshold);''', '''    float16_t centreLuma = lumas[4];
    float16_t ridgeThreshold = max(float16_t(LockRidgeAbsolute), float16_t(LockRidgeRelative) * centreLuma);
    bool ridge = hIsRidge(centreLuma, lumas[3], lumas[5], ridgeThreshold)
        || hIsRidge(centreLuma, lumas[1], lumas[7], ridgeThreshold)
        || hIsRidge(centreLuma, lumas[0], lumas[8], ridgeThreshold)
        || hIsRidge(centreLuma, lumas[2], lumas[6], ridgeThreshold);''')
rep('''    float historyAlpha = clamp(history.a, alphaMin, alphaMax);''', '''    float historyAlpha = clamp(history.a, float(alphaMin), float(alphaMax));''')
rep('''                float lanczosWeight = kernelX[x + 1] * kernelY[y + 1];
                float viewDepth''', '''                float lanczosWeight = float(kernelX[x + 1] * kernelY[y + 1]);
                float viewDepth''')
rep('''            movingShare = clamp(nearerWeight / max(reconstructionWeight, 1.0e-4), 0.0, 1.0) * (1.0 - hold);
            vec4 movingColor = nearerSum / nearerWeight;
            clipped = mix(clipped, clamp(movingColor.xyz, neighbourMin, neighbourMax), movingShare);
            historyAlpha = mix(historyAlpha, clamp(movingColor.w, alphaMin, alphaMax), movingShare);''', '''            movingShare = clamp(nearerWeight / max(float(reconstructionWeight), 1.0e-4), 0.0, 1.0) * (1.0 - hold);
            vec4 movingColor = nearerSum / nearerWeight;
            clipped = mix(clipped, clamp(movingColor.xyz, vec3(neighbourMin), vec3(neighbourMax)), movingShare);
            historyAlpha = mix(historyAlpha, clamp(movingColor.w, float(alphaMin), float(alphaMax)), movingShare);''')
rep('''    float currentWeight = accumulated > 1.0e-3 ? sampleWeight / (accumulated + sampleWeight) : 1.0;''',
'''    float currentWeight = accumulated > 1.0e-3 ? float(sampleWeight) / (accumulated + float(sampleWeight)) : 1.0;''')
rep('''        : min(accumulated + sampleWeight, motionCap) / MaxAccumulation;''', '''        : min(accumulated + float(sampleWeight), motionCap) / MaxAccumulation;''')
open(p, 'w').write(s)
print('half2 variant', name, 'from', base)
