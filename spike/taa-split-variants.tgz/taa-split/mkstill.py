# usage: mkstill.py <name> <base dir>: adds the still-surface history layer (a cost prototype of the state #1191 needs)
import sys, os, shutil
name, base = sys.argv[1], sys.argv[2]
B = '/tmp/taa-split/' + base + '/'; V = '/tmp/taa-split/' + name + '/'
os.makedirs(V, exist_ok=True)
for f in os.listdir(B): shutil.copy(B + f, V + f)
def rep(p, a, b, n=1):
    s = open(p).read(); assert s.count(a) == n, (p, a[:70], s.count(a)); open(p, 'w').write(s.replace(a, b))
p = V + 'ShaderSources.TemporalSplitResolve.cs'
rep(p, '''layout(set=0, binding=7) uniform texture2D HistoryConfidence;
layout(set=0, binding=8) uniform sampler LinearClamp;
// The members are TemporalResolveUniforms.GlslMembers, documented on the struct's fields.
layout(set=0, binding=9) uniform Resolve {''', '''layout(set=0, binding=7) uniform texture2D HistoryConfidence;
layout(set=0, binding=8) uniform texture2D StillHistory;
layout(set=0, binding=9) uniform sampler LinearClamp;
layout(set=0, binding=10) uniform Resolve {''')
rep(p, '''    float alpha;
};''', '''    float alpha; vec4 still;
};''')
rep(p, '''    return result;
}
";''', '''    // The still layer: the history of surfaces that did not move in the world, reprojected by the camera alone from
    // the centre texel's depth, and updated only where such a surface shows.
    float stillDepth = texelFetch(sampler2D(CurrentViewDepth, LinearClamp), centreTexel, 0).r;
    vec2 stillNdc = vec2(uv.x * 2.0 - 1.0, 1.0 - uv.y * 2.0);
    vec4 stillView = CurrentToPrevious * vec4(stillNdc * (CurrentDepth.x > 0.5 ? stillDepth : 1.0), stillDepth, 1.0);
    vec4 stillClip = PreviousProjection * stillView;
    vec2 stillUv = stillClip.w > 1.0e-6
        ? vec2(stillClip.x / stillClip.w * 0.5 + 0.5, 0.5 - stillClip.y / stillClip.w * 0.5) : vec2(-1.0);
    vec4 stillPrevious = textureLod(sampler2D(StillHistory, LinearClamp), stillUv, 0.0);
    bool stillHere = depthTested && !nearerMoved;
    result.still = stillHere
        ? vec4(mix(stillPrevious.rgb, result.color, max(currentWeight, 0.0625)), 1.0) : stillPrevious;
    return result;
}
";''')
rep(p, '''layout(location=1) out vec4 oState;
void main() {
    TemporalPixel p = temporalSplitPixel(ivec2(gl_FragCoord.xy));''', '''layout(location=1) out vec4 oState;
layout(location=2) out vec4 oStill;
void main() {
    TemporalPixel p = temporalSplitPixel(ivec2(gl_FragCoord.xy));
    oStill = p.still;''')
p = V + 'TemporalSplitResolve.cs'
rep(p, '''                T("PrevDepth"), T("HistoryColor"), T("HistoryConfidence"), S("LinearClamp"), U("Resolve")));''',
'''                T("PrevDepth"), T("HistoryColor"), T("HistoryConfidence"), T("StillHistory"), S("LinearClamp"),
                U("Resolve")));''')
rep(p, '''                new GpuOutputDescription(null, TemporalFormats.HistoryColor, TemporalFormats.HistoryConfidence));''',
'''                new GpuOutputDescription(null, TemporalFormats.HistoryColor, TemporalFormats.HistoryConfidence,
                    GpuPixelFormat.R16G16B16A16Float));''')
rep(p, '''        readonly IGpuResourceSet?[] _splitSets = new IGpuResourceSet?[2];''', '''        readonly IGpuResourceSet?[] _splitSets = new IGpuResourceSet?[2];
        readonly IGpuTexture?[] _still = new IGpuTexture?[2];
        readonly IGpuFramebuffer?[] _splitFramebuffers = new IGpuFramebuffer?[2];''')
rep(p, '''            _prepareSet = f.CreateResourceSet(''', '''            for (int i = 0; i < 2; i++)
            {
                _still[i]?.Dispose();
                _still[i] = f.CreateTexture(GpuTextureDescription.Texture2D((uint)history.DisplayWidth,
                    (uint)history.DisplayHeight, GpuPixelFormat.R16G16B16A16Float,
                    GpuTextureUsage.RenderTarget | GpuTextureUsage.Sampled));
            }
            _prepareSet = f.CreateResourceSet(''')
rep(p, '''                    history.Color(i), history.Confidence(i), clamp, uniforms));''', '''                    history.Color(i), history.Confidence(i), _still[i]!, clamp, uniforms));
                _splitFramebuffers[i] = f.CreateFramebuffer(null, history.Color(i), history.Confidence(i), _still[i]!);''')
rep(p, '''                cl.SetFramebuffer(history.ResolveFramebuffer(history.WriteIndex));''', '''                cl.SetFramebuffer(_splitFramebuffers[history.WriteIndex]!);''')
rep(p, '''                _splitSets[i]?.Dispose();
                _prepareFramebuffers[i]?.Dispose();''', '''                _splitSets[i]?.Dispose();
                _prepareFramebuffers[i]?.Dispose();
                _splitFramebuffers[i]?.Dispose();
                _splitFramebuffers[i] = null;''')
rep(p, '''                retired.Retire(_splitSets[i]);''', '''                retired.Retire(_splitSets[i]);
                retired.Retire(_splitFramebuffers[i]);
                _splitFramebuffers[i] = null;''')
print('still variant', name, 'from', base)
