# usage: mkvar.py <name> <base dir> <edit>...: copies the base variant's four split files and applies named edits
import sys, os, shutil
name, base, edits = sys.argv[1], sys.argv[2], sys.argv[3:]
B = '/tmp/taa-split/' + base + '/'; V = '/tmp/taa-split/' + name + '/'
os.makedirs(V, exist_ok=True)
for f in os.listdir(B): shutil.copy(B + f, V + f)
P2 = V + 'ShaderSources.TemporalSplitResolve.cs'
def rep(p, a, b, n=1):
    s = open(p).read(); assert s.count(a) == n, (p, a[:60], s.count(a)); open(p, 'w').write(s.replace(a, b))
E = {
 'poly': (P2, '''float lanczos2(float x) {
    float ax = abs(x);
    if (ax < 1.0e-5) return 1.0;
    if (ax >= 2.0) return 0.0;
    float px = 3.14159265 * ax;
    return 2.0 * sin(px) * sin(0.5 * px) / (px * px);
}''', '''float lanczos2(float x) {
    float x2 = min(x * x, 4.0);
    float a = 0.4 * x2 - 1.0;
    float b = 0.25 * x2 - 1.0;
    return (1.5625 * a * a - 0.5625) * (b * b);
}'''),
 'tap5': (P2, '''    ivec2 base = ivec2(floor(samplePos - 0.5));
    ivec2 lastTexel = ivec2(size) - ivec2(1);
    vec4 t00 = texelFetch(sampler2D(HistoryColor, LinearClamp), clamp(base, ivec2(0), lastTexel), 0);
    vec4 t10 = texelFetch(sampler2D(HistoryColor, LinearClamp), clamp(base + ivec2(1, 0), ivec2(0), lastTexel), 0);
    vec4 t01 = texelFetch(sampler2D(HistoryColor, LinearClamp), clamp(base + ivec2(0, 1), ivec2(0), lastTexel), 0);
    vec4 t11 = texelFetch(sampler2D(HistoryColor, LinearClamp), clamp(base + ivec2(1, 1), ivec2(0), lastTexel), 0);
    vec4 texelMin = min(min(t00, t10), min(t01, t11));
    vec4 texelMax = max(max(t00, t10), max(t01, t11));
    return clamp(sum / weight, texelMin, texelMax);''', '''    vec4 tapMin = min(min(min(top, left), min(middle, right)), bottom);
    vec4 tapMax = max(max(max(top, left), max(middle, right)), bottom);
    return clamp(sum / weight, tapMin, tapMax);'''),
  'hist1': (P2, '''vec4 sampleHistoryCatmullRom(vec2 uv, vec2 size) {
''', '''vec4 sampleHistoryCatmullRom(vec2 uv, vec2 size) {
    if (size.x > 0.0) return textureLod(sampler2D(HistoryColor, LinearClamp), uv, 0.0);
'''),
  'nohist': (P2, '''vec4 sampleHistoryCatmullRom(vec2 uv, vec2 size) {
''', '''vec4 sampleHistoryCatmullRom(vec2 uv, vec2 size) {
    if (size.x > 0.0) return vec4(0.5, 0.5, 0.5, 1.0) + 1.0e-30 * texelFetch(sampler2D(HistoryColor, LinearClamp), ivec2(uv), 0);
'''),
  'nomoving': (P2, '''    if (narrowMoving) {
        float ownDepth''', '''    if (narrowMoving && false) {
        float ownDepth'''),
  'statsfetch': (P2, '''            f16vec3 ycc = prepared.xyz;
            lumas[(y + 1) * 3 + (x + 1)] = ycc.x;
            momentSum += ycc;
            momentSquares += ycc * ycc;
            neighbourMin = min(neighbourMin, ycc);
            neighbourMax = max(neighbourMax, ycc);
            alphaMin = min(alphaMin, prepared.w);
            alphaMax = max(alphaMax, prepared.w);''', '''            f16vec3 ycc = prepared.xyz;'''),
  'statsfetch2': (P2, '''            reactiveDifference = max(reactiveDifference, texelReactive);
        }
    }
''', '''        }
    }
    {
        f16vec4 sA = f16vec4(texelFetch(sampler2D(Prepared, LinearClamp), centreTexel + ivec2(1, 0), 0));
        f16vec4 sB = f16vec4(texelFetch(sampler2D(Prepared, LinearClamp), centreTexel + ivec2(0, 1), 0));
        f16vec4 sC = f16vec4(texelFetch(sampler2D(Prepared, LinearClamp), centreTexel + ivec2(1, 1), 0));
        f16vec4 sD = f16vec4(texelFetch(sampler2D(Prepared, LinearClamp), centreTexel + ivec2(-1, 1), 0));
        momentSum = sA.xyz * float16_t(9.0); momentSquares = sB.xyz * float16_t(9.0) + momentSum * momentSum / float16_t(81.0);
        neighbourMin = sC.xyz; neighbourMax = sD.xyz; alphaMin = sA.w; alphaMax = sB.w; reactiveDifference = sC.w;
        for (int i = 0; i < 9; i++) lumas[i] = sD.w + float16_t(i) * sA.w;
    }
'''),
}
for e in edits:
    p, a, b = E[e]; rep(p, a, b)
print('variant', name, 'from', base, 'with', edits)
