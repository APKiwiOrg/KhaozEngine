#pragma clang diagnostic ignored "-Wmissing-prototypes"
#pragma clang diagnostic ignored "-Wmissing-braces"

#include <metal_stdlib>
#include <simd/simd.h>

using namespace metal;

template<typename T, size_t Num>
struct spvUnsafeArray
{
    T elements[Num ? Num : 1];
    
    thread T& operator [] (size_t pos) thread
    {
        return elements[pos];
    }
    constexpr const thread T& operator [] (size_t pos) const thread
    {
        return elements[pos];
    }
    
    device T& operator [] (size_t pos) device
    {
        return elements[pos];
    }
    constexpr const device T& operator [] (size_t pos) const device
    {
        return elements[pos];
    }
    
    constexpr const constant T& operator [] (size_t pos) const constant
    {
        return elements[pos];
    }
    
    threadgroup T& operator [] (size_t pos) threadgroup
    {
        return elements[pos];
    }
    constexpr const threadgroup T& operator [] (size_t pos) const threadgroup
    {
        return elements[pos];
    }
};

struct _165
{
    float4x4 _m0;
    float4x4 _m1;
    float4x4 _m2;
    float4 _m3;
    float4 _m4;
    float4 _m5;
    float4 _m6;
};

struct main0_out
{
    float4 m_860 [[color(0)]];
    float4 m_864 [[color(1)]];
    float4 m_868 [[color(2)]];
    float4 m_872 [[color(3)]];
    float4 m_875 [[color(4)]];
    float4 m_884 [[color(5)]];
    float4 m_887 [[color(6)]];
    float4 m_892 [[color(7)]];
};

struct main0_in
{
    float2 m_895 [[user(locn0)]];
};

fragment main0_out main0(main0_in in [[stage_in]], constant _165& _167 [[buffer(0)]], texture2d<float> _467 [[texture(0)]], texture2d<float> _475 [[texture(1)]], texture2d<float> _193 [[texture(2)]], texture2d<float> _181 [[texture(3)]], sampler _185 [[sampler(0)]], float4 gl_FragCoord [[position]])
{
    main0_out out = {};
    int2 _457 = int2(_167._m3.xy) - int2(1);
    int2 _465 = clamp(int2(gl_FragCoord.xy), int2(0), _457);
    float4 _473 = _467.read(uint2(_465), 0);
    float3 _490 = fast::min(fast::max(_473.xyz, float3(0.0)), float3(65504.0));
    float3 _922 = _490 / float3(1.0 + dot(_490, float3(0.2125999927520751953125, 0.715200006961822509765625, 0.072200000286102294921875)));
    float3 _499 = fast::min(fast::max(_475.read(uint2(_465), 0).xyz, float3(0.0)), float3(65504.0));
    float _1544;
    int2 _1545;
    _1545 = _465;
    _1544 = 2000000030094932439753377710080.0;
    float _1695;
    int2 _1700;
    for (int _1543 = -1; _1543 <= 1; _1545 = _1700, _1544 = _1695, _1543++)
    {
        _1695 = _1544;
        _1700 = _1545;
        float _1764;
        int2 _1767;
        for (int _1690 = -1; _1690 <= 1; _1695 = _1764, _1690++, _1700 = _1767)
        {
            int2 _534 = clamp(_465 + int2(_1690, _1543), int2(0), _457);
            float4 _963 = _193.read(uint2(_534), 0);
            float _965 = _963.x;
            float _1693;
            if (abs(_181.read(uint2(_534), 0).x) > 60000.0)
            {
                _1693 = 1000000015047466219876688855040.0;
            }
            else
            {
                float _1692;
                if (_167._m5.x > 0.5)
                {
                    _1692 = (_167._m5.y * _167._m5.z) / fma(-_965, _167._m5.z - _167._m5.y, _167._m5.z);
                }
                else
                {
                    _1692 = fma(_965, _167._m5.z - _167._m5.y, _167._m5.y);
                }
                _1693 = _1692;
            }
            bool _541 = _1693 < _1695;
            _1764 = _541 ? _1693 : _1695;
            _1767 = select(_1700, _534, bool2(_541));
        }
    }
    float2 _556 = (float2(_465) + float2(0.5)) - _167._m4.xy;
    float2 _1549;
    float2 _1552;
    bool _1558;
    if (_1544 < 2000000030094932439753377710080.0)
    {
        float4 _575 = _181.read(uint2(_1545), 0);
        _1558 = abs(_575.x) > 60000.0;
        _1552 = _575.xy;
        _1549 = (float2(_1545) + float2(0.5)) - _167._m4.xy;
    }
    else
    {
        _1558 = true;
        _1552 = float2(0.0);
        _1549 = _556;
    }
    float4 _594 = _181.read(uint2(_465), 0);
    float2 _595 = _594.xy;
    bool _600 = abs(_594.x) > 60000.0;
    float4 _607 = _193.read(uint2(_465), 0);
    float _611 = _607.x;
    float _1547;
    if (_600)
    {
        _1547 = 1000000015047466219876688855040.0;
    }
    else
    {
        float _1546;
        if (_167._m5.x > 0.5)
        {
            _1546 = (_167._m5.y * _167._m5.z) / fma(-_611, _167._m5.z - _167._m5.y, _167._m5.z);
        }
        else
        {
            _1546 = fma(_611, _167._m5.z - _167._m5.y, _167._m5.y);
        }
        _1547 = _1546;
    }
    bool _1083 = !_1558;
    float _1560;
    bool _1562;
    float _1564;
    if (_1083)
    {
        float2 _1087 = _1549 / _167._m3.xy;
        float4 _1111 = _167._m0 * float4(float2(fma(_1087.x, 2.0, -1.0), fma(-_1087.y, 2.0, 1.0)) * ((_167._m5.x > 0.5) ? _1544 : 1.0), _1544, 1.0);
        float4 _1118 = _167._m2 * _1111;
        float _1120 = _1118.w;
        bool _1563;
        float _1565;
        if (_1120 > 9.9999999747524270787835121154785e-07)
        {
            float _1152 = length((float2(fma(_1118.x / _1120, 0.5, 0.5), fma(-(_1118.y / _1120), 0.5, 0.5)) - (_1087 - _1552)) * _167._m3.xy);
            _1565 = _1152;
            _1563 = _1152 <= fma(length(_1552 * _167._m3.xy), 0.0009765625, 0.5);
        }
        else
        {
            _1565 = 1000000015047466219876688855040.0;
            _1563 = false;
        }
        _1564 = _1565;
        _1562 = _1563;
        _1560 = -_1111.z;
    }
    else
    {
        _1564 = 0.0;
        _1562 = true;
        _1560 = 1000000015047466219876688855040.0;
    }
    float _1574;
    float _1589;
    if (_1083)
    {
        float2 _1573;
        if (_600)
        {
            float2 _652 = _556 / _167._m3.xy;
            float4 _665 = _167._m1 * float4(fma(_652.x, 2.0, -1.0), fma(-_652.y, 2.0, 1.0), 1.0, 1.0);
            float _667 = _665.w;
            float2 _1568;
            if (_667 > 9.9999999747524270787835121154785e-07)
            {
                _1568 = _652 - float2(fma(_665.x / _667, 0.5, 0.5), fma(-(_665.y / _667), 0.5, 0.5));
            }
            else
            {
                _1568 = float2(2.0);
            }
            _1573 = _1568;
        }
        else
        {
            _1573 = _595;
        }
        _1589 = length(_1573 * _167._m3.xy);
        _1574 = length((_1552 - _1573) * _167._m3.xy);
    }
    else
    {
        _1589 = 0.0;
        _1574 = 0.0;
    }
    float _708 = length(_1552 * _167._m3.xy);
    bool _712 = _1574 > fast::max(0.001000000047497451305389404296875, _708 * 0.001953125);
    bool _718 = _1547 > (_1544 * 1.019999980926513671875);
    bool _721 = !_1562;
    bool _727 = (_721 && (_1574 > 1.25)) && _718;
    bool _757;
    if (!_721)
    {
        _757 = _1564 > fma(_708, 0.0009765625, (((0.001000000047497451305389404296875 * _167._m2[0].x) * _167._m3.x) * 0.5) / ((_167._m5.x > 0.5) ? _1544 : 1.0));
    }
    else
    {
        _757 = _721;
    }
    bool _764 = ((_167._m4.w > 0.5) && (!_727)) && _757;
    bool _782;
    if (_764)
    {
        bool _1590;
        if (_712)
        {
            _1590 = (_1589 > _708) && _718;
        }
        else
        {
            _1590 = _1564 > (2.0 * _708);
        }
        _782 = _1590;
    }
    else
    {
        _782 = _764;
    }
    bool _786 = _727 || _782;
    bool _796;
    if (_786)
    {
        spvUnsafeArray<bool, 8> _1167;
        for (int _1605 = 0; _1605 < 8; _1605++)
        {
            int _1178 = _1605 & 1;
            int _1179 = _1178 + 1;
            int2 _1681;
            if (_1605 < 2)
            {
                _1681 = int2((-1) - _1178, 0);
            }
            else
            {
                int2 _1680;
                if (_1605 < 4)
                {
                    _1680 = int2(_1179, 0);
                }
                else
                {
                    int2 _1679;
                    if (_1605 < 6)
                    {
                        _1679 = int2(0, (-1) - _1178);
                    }
                    else
                    {
                        _1679 = int2(0, _1179);
                    }
                    _1680 = _1679;
                }
                _1681 = _1680;
            }
            int2 _1212 = clamp(_1545 + _1681, int2(0), _457);
            float4 _1301 = _193.read(uint2(_1212), 0);
            float _1303 = _1301.x;
            float _1683;
            if (abs(_181.read(uint2(_1212), 0).x) > 60000.0)
            {
                _1683 = 1000000015047466219876688855040.0;
            }
            else
            {
                float _1682;
                if (_167._m5.x > 0.5)
                {
                    _1682 = (_167._m5.y * _167._m5.z) / fma(-_1303, _167._m5.z - _167._m5.y, _167._m5.z);
                }
                else
                {
                    _1682 = fma(_1303, _167._m5.z - _167._m5.y, _167._m5.y);
                }
                _1683 = _1682;
            }
            bool _1219 = _1544 < (_1683 * 0.980000019073486328125);
            bool _1228;
            if (!_1219)
            {
                _1228 = _1683 < (_1544 * 0.980000019073486328125);
            }
            else
            {
                _1228 = _1219;
            }
            _1167[_1605] = !_1228;
        }
        bool _1240 = !(_1167[0] && _1167[2]);
        bool _1249;
        if (_1240)
        {
            _1249 = !(_1167[0] && _1167[1]);
        }
        else
        {
            _1249 = _1240;
        }
        bool _1258;
        if (_1249)
        {
            _1258 = !(_1167[2] && _1167[3]);
        }
        else
        {
            _1258 = _1249;
        }
        bool _1264 = !(_1167[4] && _1167[6]);
        bool _1273;
        if (_1264)
        {
            _1273 = !(_1167[4] && _1167[5]);
        }
        else
        {
            _1273 = _1264;
        }
        bool _1282;
        if (_1273)
        {
            _1282 = !(_1167[6] && _1167[7]);
        }
        else
        {
            _1282 = _1273;
        }
        _796 = _1258 || _1282;
    }
    else
    {
        _796 = _786;
    }
    bool _1640;
    float _1654;
    if (_727)
    {
        float _1633;
        bool _1635;
        if (!_600)
        {
            float2 _1372 = _556 / _167._m3.xy;
            float4 _1396 = _167._m0 * float4(float2(fma(_1372.x, 2.0, -1.0), fma(-_1372.y, 2.0, 1.0)) * ((_167._m5.x > 0.5) ? _1547 : 1.0), _1547, 1.0);
            float4 _1403 = _167._m2 * _1396;
            float _1405 = _1403.w;
            bool _1636;
            if (_1405 > 9.9999999747524270787835121154785e-07)
            {
                _1636 = length((float2(fma(_1403.x / _1405, 0.5, 0.5), fma(-(_1403.y / _1405), 0.5, 0.5)) - (_1372 - _595)) * _167._m3.xy) <= fma(length(_595 * _167._m3.xy), 0.0009765625, 0.5);
            }
            else
            {
                _1636 = false;
            }
            _1635 = _1636;
            _1633 = -_1396.z;
        }
        else
        {
            _1635 = true;
            _1633 = 1000000015047466219876688855040.0;
        }
        _1654 = _1633;
        _1640 = _1635;
    }
    else
    {
        _1654 = _1560;
        _1640 = _1562;
    }
    float _1446 = _922.x;
    float _1450 = 0.5 * _922.y;
    float _1453 = _922.z;
    out.m_860 = float4(fma(0.25, _1453, fma(0.25, _1446, _1450)), 0.0, 0.0, 1.0);
    out.m_864 = float4(fma(0.5, _1446, _1453 * (-0.5)), 0.0, 0.0, 1.0);
    out.m_868 = float4(fma(-0.25, _1453, fma(-0.25, _1446, _1450)), 0.0, 0.0, 1.0);
    out.m_872 = float4(abs(dot(_922, float3(0.2125999927520751953125, 0.715200006961822509765625, 0.072200000286102294921875)) - dot(_499 / float3(1.0 + dot(_499, float3(0.2125999927520751953125, 0.715200006961822509765625, 0.072200000286102294921875))), float3(0.2125999927520751953125, 0.715200006961822509765625, 0.072200000286102294921875))), 0.0, 0.0, 1.0);
    out.m_875 = float4(_473.w, select(_1552, _595, bool2(_727)), float((((((int(_727 ? _600 : _1558) | (_1640 ? 2 : 0)) | (_757 ? 4 : 0)) | ((_782 && (!_796)) ? 8 : 0)) | (_727 ? 16 : 0)) | ((_727 && _796) ? 32 : 0)) | (_712 ? 64 : 0)));
    out.m_884 = float4(_1654, 0.0, 0.0, 1.0);
    out.m_887 = float4(fast::clamp(_1574, 0.0, 1.0), 0.0, 0.0, 1.0);
    out.m_892 = float4(fma(in.m_895.x, 1.0000000031710768509710513471353e-30, _1547), 0.0, 0.0, 1.0);
    return out;
}

