#!/bin/zsh
# usage: msldump.sh <tag>: emits the MSL of the single resolve and the two passes for the current source into
# /tmp/taa-split/msl-<tag> (by blanking their hashes so the byte-equality fact writes its evidence), restores the table,
# then probes them
set -u
W=/Users/antonio/KhaozEngine/.worktrees/taa-split
T=$W/KhaozEngine.Render.Tests/Gpu/msl-hashes/metal-msl.sha256.txt
E=$W/KhaozEngine.Render.Tests/Gpu/msl-evidence
cd $W && dotnet build KhaozEngine.Render.Tests/KhaozEngine.Render.Tests.csproj -c Release > /tmp/taa-split/msl-$1.build 2>&1 || echo "build failed"
cp $T /tmp/taa-split/msl-table.tmp
perl -i -pe 's/^(Temporal(Resolve|Prepare|Split)\.fragment )[0-9a-f]{8}/${1}00000000/' $T
dotnet test KhaozEngine.Render.Tests/KhaozEngine.Render.Tests.csproj -c Release --no-build --filter "FullyQualifiedName~MetalMslByteEquality" > /tmp/taa-split/msl-$1.log 2>&1
cp /tmp/taa-split/msl-table.tmp $T
git -C $W diff --quiet -- $T && echo "table restored" || echo "TABLE RESTORE FAILED"
rm -rf /tmp/taa-split/msl-$1 && mkdir -p /tmp/taa-split/msl-$1 && mv $E/Temporal{Resolve,Prepare,Split}.fragment.metal /tmp/taa-split/msl-$1/
rm -rf $E 2>/dev/null; git -C $W status --short -- KhaozEngine.Render.Tests
for p in Resolve Prepare Split; do M=/tmp/taa-split/msl-$1/Temporal$p.fragment.metal; echo "$p bytes $(wc -c < $M) lines $(wc -l < $M) loops $(grep -c 'for (' $M) arrays $(grep -c 'spvUnsafeArray<' $M) reads $(grep -o '\.read(' $M | wc -l | tr -d ' ') samples $(grep -o '\.sample(' $M | wc -l | tr -d ' ')"; done
