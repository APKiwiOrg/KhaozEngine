import re, sys
# every printed line of a detailed test log, prefixed by its full test name, timing lines dropped
test = None
out = []
for line in open(sys.argv[1], errors='replace'):
    line = line.rstrip('\n')
    m = re.match(r'^\s+(Passed|Failed|Skipped) (KhaozEngine\.\S.*?)(?: \[[^\]]*\])?$', line)
    if m:
        test = m.group(2)
        continue
    if re.match(r'^\s+(Standard Output Messages:|Stack Trace:|Error Message:)', line) or not line.strip():
        continue
    if not line.startswith(' ') or test is None:
        continue
    if re.search(r'\d+ ms$|: \d+(\.\d+)? s$|\d+(\.\d+)? s of rendering|Seconds', line):
        continue
    out.append(test.split('.Gpu.')[-1] + ' :: ' + line.strip())
for l in sorted(out):
    print(l)
