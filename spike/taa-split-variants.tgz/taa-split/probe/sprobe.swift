// Scratch probe: times the emitted MSL of the single resolve, and of the two-pass resolve's pass one and pass two, as
// fragment passes on a synthetic static textured wall with GPU timestamps. Pass one runs first and its outputs are pass
// two's inputs. usage: sprobe <single.metal> <prepare.metal> <split.metal> [iw ih dw dh]
import Foundation
import Metal

let a = CommandLine.arguments
let iw = a.count > 7 ? Int(a[4])! : 1707, ih = a.count > 7 ? Int(a[5])! : 960
let dw = a.count > 7 ? Int(a[6])! : 2560, dh = a.count > 7 ? Int(a[7])! : 1440
let dev = MTLCreateSystemDefaultDevice()!
let opts = MTLCompileOptions()
opts.languageVersion = .version3_2
opts.fastMathEnabled = true
let vsrc = """
#include <metal_stdlib>
using namespace metal;
struct VOut { float4 pos [[position]]; float2 uv [[user(locn0)]]; };
vertex VOut vmain(uint vid [[vertex_id]]) {
    float2 p = float2(float((vid << 1) & 2), float(vid & 2));
    VOut o; o.pos = float4(p * 2.0 - 1.0, 0.0, 1.0); o.uv = p; return o;
}
"""
let vlib = try! dev.makeLibrary(source: vsrc, options: opts)
func pipeline(_ path: String, _ formats: [MTLPixelFormat]) -> MTLRenderPipelineState {
    let src = try! String(contentsOfFile: path, encoding: .utf8)
    let lib = try! dev.makeLibrary(source: src, options: opts)
    let pd = MTLRenderPipelineDescriptor()
    pd.vertexFunction = vlib.makeFunction(name: "vmain")
    pd.fragmentFunction = lib.makeFunction(name: "main0")
    for (i, f) in formats.enumerated() { pd.colorAttachments[i].pixelFormat = f }
    return try! dev.makeRenderPipelineState(descriptor: pd)
}
func count(_ path: String, _ pattern: String) -> Int {
    let s = try! String(contentsOfFile: path, encoding: .utf8)
    return s.components(separatedBy: pattern).count - 1
}
func tex(_ w: Int, _ h: Int, _ f: MTLPixelFormat, _ rt: Bool = false) -> MTLTexture {
    let d = MTLTextureDescriptor.texture2DDescriptor(pixelFormat: f, width: w, height: h, mipmapped: false)
    d.usage = rt ? [.renderTarget, .shaderRead] : [.shaderRead]
    d.storageMode = .private
    if !rt { d.storageMode = .shared }
    return dev.makeTexture(descriptor: d)!
}
func fillHalf(_ t: MTLTexture, _ ch: Int, _ f: (Int, Int, Int) -> Float) {
    var b = [Float16](repeating: 0, count: t.width * t.height * ch)
    for y in 0..<t.height { for x in 0..<t.width { for c in 0..<ch { b[(y * t.width + x) * ch + c] = Float16(f(x, y, c)) } } }
    t.replace(region: MTLRegionMake2D(0, 0, t.width, t.height), mipmapLevel: 0, withBytes: b, bytesPerRow: t.width * ch * 2)
}
func fillFloat(_ t: MTLTexture, _ f: (Int, Int) -> Float) {
    var b = [Float](repeating: 0, count: t.width * t.height)
    for y in 0..<t.height { for x in 0..<t.width { b[y * t.width + x] = f(x, y) } }
    t.replace(region: MTLRegionMake2D(0, 0, t.width, t.height), mipmapLevel: 0, withBytes: b, bytesPerRow: t.width * 4)
}
// The static textured wall of the single-pass probe: orthographic, near 1, far 21, linear depth 11, no motion.
let scene = tex(iw, ih, .rgba16Float), opaque = tex(iw, ih, .rgba16Float), depth = tex(iw, ih, .r32Float)
let motion = tex(iw, ih, .rg16Float), prevDepth = tex(iw, ih, .r32Float)
let hist = tex(dw, dh, .rgba16Float), state = tex(dw, dh, .rg16Float)
let wall: (Int, Int, Int) -> Float = { x, y, c in c == 3 ? 1 : 0.4 + 0.3 * sin(Float(x) * 0.11 + Float(c)) * cos(Float(y) * 0.07) }
fillHalf(scene, 4, wall); fillHalf(opaque, 4, wall); fillFloat(depth) { _, _ in 0.5 }; fillHalf(motion, 2) { _, _, _ in 0 }
fillFloat(prevDepth) { _, _ in 11 }
fillHalf(hist, 4) { x, y, c in wall(x * iw / dw, y * ih / dh, c) }; fillHalf(state, 2) { _, _, c in c == 0 ? 0.9 : 0 }
var u = [Float](repeating: 0, count: 64)
for i in 0..<4 { u[i * 4 + i] = 1; u[16 + i * 4 + i] = 1; u[32 + i * 4 + i] = 1 }
u[10] = -1
u[48] = Float(iw); u[49] = Float(ih); u[50] = Float(dw); u[51] = Float(dh)
u[52] = 0.125; u[53] = -0.375; u[54] = Float(dw) / Float(iw); u[55] = 1
u[56] = 0; u[57] = 1; u[58] = 21
let ubuf = dev.makeBuffer(bytes: u, length: 256, options: .storageModeShared)!
let sd = MTLSamplerDescriptor(); sd.minFilter = .linear; sd.magFilter = .linear
sd.sAddressMode = .clampToEdge; sd.tAddressMode = .clampToEdge
let samp = dev.makeSamplerState(descriptor: sd)!
let q = dev.makeCommandQueue()!

// Pass one's outputs: five targets for the half float layout, eight for the single float one.
let prepareOutputs = count(a[2], "[[color(")
let prepareFormats: [MTLPixelFormat] = prepareOutputs == 8
    ? [.r32Float, .r32Float, .r32Float, .r32Float, .rgba16Float, .r32Float, .r32Float, .r32Float]
    : [.rgba16Float, .rgba16Float, .r32Float, .r32Float, .r32Float]
let prepared = prepareFormats.map { tex(iw, ih, $0, true) }
let splitOutputs = count(a[3], "[[color(")
let display = [tex(dw, dh, .rgba16Float, true), tex(dw, dh, .rg16Float, true)]
let splitDisplay = splitOutputs == 3 ? display + [tex(dw, dh, .rgba16Float, true)] : display
let single = pipeline(a[1], [.rgba16Float, .rg16Float])
let prepare = pipeline(a[2], prepareFormats)
let split = pipeline(a[3], splitOutputs == 3 ? [.rgba16Float, .rg16Float, .rgba16Float] : [.rgba16Float, .rg16Float])
// Pass two reads pass one's targets but the depth, then this frame's depth (pass one's last target), the stored one,
// the history and the state.
let splitInputs = Array(prepared.dropLast()) + [prepared.last!, prevDepth, hist, state] + (splitOutputs == 3 ? [hist] : [])

func encode(_ cb: MTLCommandBuffer, _ pso: MTLRenderPipelineState, _ targets: [MTLTexture], _ inputs: [MTLTexture]) {
    let rp = MTLRenderPassDescriptor()
    for (i, t) in targets.enumerated() {
        rp.colorAttachments[i].texture = t; rp.colorAttachments[i].loadAction = .dontCare
        rp.colorAttachments[i].storeAction = .store
    }
    let e = cb.makeRenderCommandEncoder(descriptor: rp)!
    e.setRenderPipelineState(pso)
    e.setFragmentBuffer(ubuf, offset: 0, index: 0)
    for (i, t) in inputs.enumerated() { e.setFragmentTexture(t, index: i) }
    e.setFragmentSamplerState(samp, index: 0)
    e.drawPrimitives(type: .triangle, vertexStart: 0, vertexCount: 3)
    e.endEncoding()
}
enum Which { case single, prepare, split, both }
func run(_ w: Which, _ passes: Int) -> Double {
    let cb = q.makeCommandBuffer()!
    for _ in 0..<passes {
        switch w {
        case .single: encode(cb, single, display, [scene, opaque, depth, motion, prevDepth, hist, state])
        case .prepare: encode(cb, prepare, prepared, [scene, opaque, depth, motion])
        case .split: encode(cb, split, splitDisplay, splitInputs)
        case .both:
            encode(cb, prepare, prepared, [scene, opaque, depth, motion])
            encode(cb, split, splitDisplay, splitInputs)
        }
    }
    cb.commit(); cb.waitUntilCompleted()
    return (cb.gpuEndTime - cb.gpuStartTime) * 1000 / Double(passes)
}
for w in [Which.single, .prepare, .split, .both] { _ = run(w, 5) }
let nb = Int(ProcessInfo.processInfo.environment["PROBE_BUFFERS"] ?? "25")!
var times: [String: [Double]] = [:]
// Interleaved: one buffer of each in turn, so drift lands on all four.
for _ in 0..<nb { for (n, w) in [("single", Which.single), ("pass one", .prepare), ("pass two", .split), ("both", .both)] {
    times[n, default: []].append(run(w, 20)) } }
for n in ["single", "pass one", "pass two", "both"] {
    let t = times[n]!.sorted()
    print(String(format: "%@ %dx%d from %dx%d: median %.3f ms, min %.3f, max %.3f (%d buffers of 20)", n, dw, dh, iw, ih,
        t[nb / 2], t[0], t[nb - 1], nb))
}
