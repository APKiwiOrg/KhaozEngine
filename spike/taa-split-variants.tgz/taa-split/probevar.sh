#!/bin/zsh
# usage: probevar.sh <variant dir> [iw ih dw dh]: swaps the variant in, dumps its MSL, swaps the pristine split back,
# probes the single resolve, pass one, pass two and both
set -u
cd /tmp/taa-split
zsh swap.sh $1 > /dev/null
zsh msldump.sh $1 | grep -v "table restored"
zsh swap.sh orig > /dev/null
git -C /Users/antonio/KhaozEngine/.worktrees/taa-split status --short | grep -q . && echo "WORKTREE NOT CLEAN" || echo "worktree clean"
echo "load $(sysctl -n vm.loadavg)"
./probe/sprobe msl-$1/TemporalResolve.fragment.metal msl-$1/TemporalPrepare.fragment.metal msl-$1/TemporalSplit.fragment.metal ${@:2}
