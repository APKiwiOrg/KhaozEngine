#!/bin/zsh
# usage: rebake.sh: rewrites the shader corpus and the HLSL, MSL and SPIR-V hash tables, then lists what moved
set -u
cd /Users/antonio/KhaozEngine/.worktrees/taa-split
P=KhaozEngine.Render.Tests/KhaozEngine.Render.Tests.csproj
KE_WRITE_SHADER_CORPUS=1 dotnet test $P -c Release --no-build --filter "FullyQualifiedName~ShaderCorpusTests" > /tmp/taa-split/rebake-corpus.log 2>&1; echo "corpus exit $?"
KE_UPDATE_HLSL_HASHES=1 dotnet test $P -c Release --no-build --filter "FullyQualifiedName~D3D11HlslByteEquality" > /tmp/taa-split/rebake-hlsl.log 2>&1; echo "hlsl exit $?"
KE_UPDATE_MSL_HASHES=1 dotnet test $P -c Release --no-build --filter "FullyQualifiedName~MetalMslByteEquality" > /tmp/taa-split/rebake-msl.log 2>&1; echo "msl exit $?"
KE_UPDATE_SPIRV_HASHES=1 dotnet test $P -c Release --no-build --filter "FullyQualifiedName~VulkanSpirvByteEquality" > /tmp/taa-split/rebake-spirv.log 2>&1; echo "spirv exit $?"
git status --short
for f in $(git diff --name-only | grep -E "hashes|corpus"); do echo "== $f"; git diff -U0 -- $f | grep "^[-+][A-Za-z]" | cut -c1-60; done
dotnet test $P -c Release --no-build --filter "FullyQualifiedName~ShaderCorpusTests|FullyQualifiedName~D3D11HlslByteEquality|FullyQualifiedName~MetalMslByteEquality|FullyQualifiedName~VulkanSpirvByteEquality" > /tmp/taa-split/rebake-verify.log 2>&1; echo "verify exit $?"; grep -E "Passed!|Failed!" /tmp/taa-split/rebake-verify.log | sed -E 's/ - .*//'
