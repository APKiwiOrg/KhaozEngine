#!/bin/zsh
# usage: swap.sh <variant dir name | orig>: copies the variant's split files into the worktree
set -u
W=/Users/antonio/KhaozEngine/.worktrees/taa-split/KhaozEngine.Render3D
V=/tmp/taa-split/$1
cp $V/ShaderSources.TemporalSplit.cs $V/ShaderSources.TemporalSplitResolve.cs $V/TemporalSplitFormats.cs $W/Internal/
cp $V/TemporalSplitResolve.cs $W/Rendering/
cd $W/.. && echo "swapped in $1: $(git status --short | tr '\n' ' ')"
